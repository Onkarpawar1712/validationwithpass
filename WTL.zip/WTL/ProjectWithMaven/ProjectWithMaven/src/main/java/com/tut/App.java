package com.tut;



import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
        System.out.println( "Projet started!" );
        SessionFactory factory= new Configuration().configure().buildSessionFactory();
        //createing student
        Student st=new Student();
        st.setId(101);
        st.setName("Sanika");
        st.setCity("Islampur");
        System.out.println(st);
        
        
        
		/*
		 * Address add=new Address(); add.setStreet("Street1"); add.setCity("Sangli");
		 * add.setOpen(true); add.setAddedDate(new Date()); add.setX(123.43);
		 * 
		 * FileInputStream fis= new FileInputStream("src/main/java/pic.jpeg"); byte[]
		 * data=new byte[fis.available()]; fis.read(data); add.setImage(data);
		 */
        Session session=factory.openSession();
       org.hibernate.Transaction tx=session.beginTransaction();
        session.save(st);
		/* session.save(add); */
        tx.commit();
        session.close();
        System.out.println("Done.....");
    }
}
